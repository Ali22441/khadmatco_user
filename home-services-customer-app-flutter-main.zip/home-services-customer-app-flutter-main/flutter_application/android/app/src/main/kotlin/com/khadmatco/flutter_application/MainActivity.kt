package com.khadmatco.flutter_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
