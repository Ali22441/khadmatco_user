package com.khadmatco.home_services

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
